/*
 * (c)2002-2015 Skava. All rights reserved. The Skava system, including without
 * limitation, all software and other elements thereof, are owned or controlled
 * exclusively by Skava and protected by copyright, patent, and other laws. Use
 * without permission is prohibited. For further information contact Skava at
 * info@skava.com.
 */

var appendFooterElemName = 'root-footer'
function ReactFooterCompLoad() {
    var FooterComp = function(props) {
      var renderTopPanel = function renderTopPanel(props) {
        return React.createElement("div", {
          className: "container-fluid flex-space-between"
        }, React.createElement("div", {
          className: "list-with-title-wrapper"
        }, React.createElement("h3", {
          className: "title"
        }, "Products"), React.createElement("ul", {
          className: "list"
        }, React.createElement("li", {
          className: "list-item"
        }, React.createElement("a", {
          className: "link-styles",
          href: "https://www.skava.com/overview/experience-management-skavastudio/"
        }, "Experience Management SkavaSTUDIO")), React.createElement("li", {
          className: "list-item"
        }, React.createElement("a", {
          className: "link-styles",
          href: "https://www.skava.com/ecommerce-microservices-for-innovation/"
        }, "Ecommerce Microservices")), React.createElement("li", {
          className: "list-item"
        }, React.createElement("a", {
          className: "link-styles",
          href: "https://www.skava.com/framework/"
        }, "Framework")), React.createElement("li", {
          className: "list-item"
        }, React.createElement("a", {
          className: "link-styles",
          href: "https://www.skava.com/modular-storefront/"
        }, "React/Node.Js storefront")))), React.createElement("div", {
          className: "list-with-title-wrapper"
        }, React.createElement("h3", {
          className: "title"
        }, "Resources"), React.createElement("ul", {
          className: "list"
        }, React.createElement("li", {
          className: "list-item"
        }, React.createElement("a", {
          className: "link-styles",
          href: "https://www.skava.com/resources/"
        }, "Resources")), React.createElement("li", {
          className: "list-item"
        }, React.createElement("a", {
          className: "link-styles",
          href: "https://www.skava.com/partners/"
        }, "Partners")), React.createElement("li", {
          className: "list-item"
        }, React.createElement("a", {
          className: "link-styles",
          href: "https://www.skava.com/blog/"
        }, "Blog")), React.createElement("li", {
          className: "list-item"
        }, React.createElement("a", {
          className: "link-styles",
          href: "https://www.developer.skava.com"
        }, "Skava Dev Portal")))), React.createElement("div", {
          className: "list-with-title-wrapper"
        }, React.createElement("h3", {
          className: "title"
        }, "Company"), React.createElement("ul", {
          className: "list"
        }, React.createElement("li", {
          className: "list-item"
        }, React.createElement("a", {
          className: "link-styles",
          href: "https://www.skava.com/about/"
        }, "About")), React.createElement("li", {
          className: "list-item"
        }, React.createElement("a", {
          className: "link-styles",
          href: "https://www.skava.com/about/"
        }, "Careers")), React.createElement("li", {
          className: "list-item"
        }, React.createElement("a", {
          className: "link-styles",
          href: "https://www.skava.com/privacy-policy/"
        }, "Privacy Policy")), React.createElement("li", {
          className: "list-item"
        }, React.createElement("a", {
          className: "link-styles"
        }, "Email us")))), React.createElement("address", {
          className: "address-wrapper"
        }, React.createElement("span", {
          className: "address-item"
        }, "Skava Corporate Headquarters"), React.createElement("span", {
          className: "address-item"
        }, "555 Mission St., Suite 1950"), React.createElement("span", {
          className: "address-item"
        }, "San Francisco, CA 94105"), React.createElement("span", {
          className: "address-item telephone-number"
        }, "877-554-2176"), React.createElement("a", {
          className: "request-a-demo",
          href: "https://www.skava.com/about/"
        }, "Request a demo")));
      };
    
      var renderBottomPanel = function renderBottomPanel(props) {
        return React.createElement("div", {
          className: "container-fluid flex-space-between flex-align-center height-50"
        }, React.createElement("small", null, "\xA9 2019 Skava. All Rights Reserved."), React.createElement("div", {
          className: "svg-icons-wrapper"
        }, React.createElement("a", {
          className: "icon-link twitter-icon",
          href: "https://twitter.com/skava",
          target: "_blank"
        }, React.createElement("svg", {
          className: "svg-icon",
          xmlns: "http://www.w3.org/2000/svg",
          viewBox: "0 0 612 612"
        }, React.createElement("path", {
          d: "M612 116.258a250.714 250.714 0 0 1-72.088 19.772c25.929-15.527 45.777-40.155 55.184-69.411-24.322 14.379-51.169 24.82-79.775 30.48-22.907-24.437-55.49-39.658-91.63-39.658-69.334 0-125.551 56.217-125.551 125.513 0 9.828 1.109 19.427 3.251 28.606-104.326-5.24-196.835-55.223-258.75-131.174-10.823 18.51-16.98 40.078-16.98 63.101 0 43.559 22.181 81.993 55.835 104.479a125.556 125.556 0 0 1-56.867-15.756v1.568c0 60.806 43.291 111.554 100.693 123.104-10.517 2.83-21.607 4.398-33.08 4.398-8.107 0-15.947-.803-23.634-2.333 15.985 49.907 62.336 86.199 117.253 87.194-42.947 33.654-97.099 53.655-155.916 53.655-10.134 0-20.116-.612-29.944-1.721 55.567 35.681 121.536 56.485 192.438 56.485 230.948 0 357.188-191.291 357.188-357.188l-.421-16.253c24.666-17.593 46.005-39.697 62.794-64.861z",
          fill: "#010002"
        }))), React.createElement("a", {
          className: "icon-link facebook-icon",
          href: "https://facebook.com/pages/Skava/5526864597",
          target: "_blank"
        }, React.createElement("svg", {
          className: "svg-icon",
          xmlns: "http://www.w3.org/2000/svg",
          viewBox: "0 0 90 90"
        }, React.createElement("path", {
          d: "M72.089,0.02L59.624,0C45.62,0,36.57,9.285,36.57,23.656v10.907H24.037c-1.083,0-1.96,0.878-1.96,1.961v15.803 c0,1.083,0.878,1.96,1.96,1.96h12.533v39.876c0,1.083,0.877,1.96,1.96,1.96h16.352c1.083,0,1.96-0.878,1.96-1.96V54.287h14.654 c1.083,0,1.96-0.877,1.96-1.96l0.006-15.803c0-0.52-0.207-1.018-0.574-1.386c-0.367-0.368-0.867-0.575-1.387-0.575H56.842v-9.246 c0-4.444,1.059-6.7,6.848-6.7l8.397-0.003c1.082,0,1.959-0.878,1.959-1.96V1.98C74.046,0.899,73.17,0.022,72.089,0.02z"
        }))), React.createElement("a", {
          className: "icon-link linkedin-icon",
          href: "https://linkedin.com/company/skava/",
          target: "_blank"
        }, React.createElement("svg", {
          className: "svg-icon",
          xmlns: "http://www.w3.org/2000/svg",
          viewBox: "0 0 478.165 478.165"
        }, React.createElement("path", {
          d: "M478.165,290.794v176.742H375.638V302.549c0-41.481-14.783-69.673-51.881-69.673 c-28.371,0-45.107,19.087-52.578,37.456c-2.69,6.615-3.507,15.879-3.507,25.024v172.159H165.246c0,0,1.375-279.328,0-308.257 h102.447v43.692c-0.139,0.359-0.438,0.657-0.578,1.056h0.578v-1.056c13.687-20.999,37.934-50.925,92.385-50.925 C427.659,152.026,478.165,196.077,478.165,290.794z M57.997,10.629C22.952,10.629,0,33.621,0,63.945 c0,29.507,22.275,53.276,56.682,53.276H57.3c35.822,0,58.017-23.769,58.017-53.276C114.62,33.621,93.123,10.629,57.997,10.629z M6.117,467.535h102.467V159.239H6.117V467.535z"
        }))), React.createElement("a", {
          className: "icon-link youtube-icon",
          href: "https://youtube.com/user/SkavaInc?feature=watch",
          target: "_blank"
        }, React.createElement("svg", {
          className: "svg-icon",
          xmlns: "http://www.w3.org/2000/svg",
          viewBox: "0 0 18.875 18.875"
        }, React.createElement("path", {
          d: "M17.905 10.877v5.564c0 .348-.073.665-.221.956a2.472 2.472 0 0 1-.603.769 2.895 2.895 0 0 1-.88.519c-.335.126-.695.19-1.083.19H3.745c-.379 0-.736-.064-1.07-.19a2.876 2.876 0 0 1-.881-.519 2.551 2.551 0 0 1-.604-.769 2.084 2.084 0 0 1-.22-.956v-5.564c0-.33.073-.645.221-.944.148-.3.352-.559.604-.773.253-.215.547-.39.881-.52s.691-.196 1.07-.196h11.373a3.063 3.063 0 0 1 1.963.716c.255.215.455.474.603.773s.22.614.22.944zM4.507 17.062v-5.869h1.395v-.887H2.136v.862h1.207v5.894h1.164zm.569-13.653L3.517 0h1.357l.776 2.548L6.423 0h1.355l-1.46 3.409v3.97H5.076v-3.97zm3.665 8.646H7.576v3.133c0 .227.002.403.011.524.008.124-.009.202-.051.235-.035.135-.133.234-.3.298-.161.062-.286-.026-.373-.273-.018-.033-.02-.116-.011-.246.008-.132.011-.303.011-.515l-.024-3.156H5.673l.027 3.107c0 .244-.006.448-.014.613s-.006.289.014.374l.049.438a.49.49 0 0 0 .242.374.879.879 0 0 0 .473.128c.184 0 .362-.031.534-.091.175-.06.333-.141.481-.245.147-.105.256-.219.322-.337l-.023.62.963.025v-5.006zM7.675 3.93c0-.465.045-.851.127-1.152.104-.314.267-.538.496-.674.229-.169.52-.254.875-.254.312 0 .572.052.786.152.21.085.384.232.519.444.102.154.179.325.229.521.048.211.075.494.075.85v1.329c0 .483-.027.829-.075 1.042-.02.193-.102.409-.256.646-.151.21-.315.35-.492.418a1.651 1.651 0 0 1-.724.151c-.276 0-.533-.042-.759-.127a.785.785 0 0 1-.469-.366 1.78 1.78 0 0 1-.256-.572c-.049-.23-.076-.573-.076-1.039V3.93zm1.04 2.066c0 .135.051.256.153.362a.51.51 0 0 0 .728.005.486.486 0 0 0 .157-.367V3.245a.52.52 0 0 0-.157-.385.5.5 0 0 0-.361-.16.493.493 0 0 0-.36.16.523.523 0 0 0-.16.385v2.751zm3.79 9.634v-2.599c0-.498-.176-.854-.53-1.064a.817.817 0 0 0-.407-.102c-.28 0-.6.131-.963.393v-1.952H9.439v6.706l.964-.025.075-.418c.313.263.596.423.843.482.251.058.46.035.634-.071.174-.104.309-.277.405-.52.096-.24.145-.519.145-.83zM11.1 12.512c.135 0 .253.04.36.121.105.08.158.171.158.271v2.942c0 .101-.053.188-.158.265a.606.606 0 0 1-.36.115.613.613 0 0 1-.364-.115c-.104-.076-.155-.164-.155-.265v-2.942c0-.101.052-.191.155-.271a.586.586 0 0 1 .364-.121zm.543-5.653a.742.742 0 0 1-.062-.21 1.575 1.575 0 0 0-.04-.209 1.94 1.94 0 0 1-.024-.344V2.055h1.09v4.03c0 .103.037.189.113.267a.422.422 0 0 0 .305.114c.119 0 .22-.039.304-.114a.348.348 0 0 0 .13-.267v-4.03h1.011v5.172h-1.29l.023-.418c-.119.168-.231.3-.342.392a.823.823 0 0 1-.444.127.86.86 0 0 1-.482-.127.965.965 0 0 1-.292-.342zm4.538 8.443h-.873v.569c0 .136-.049.24-.146.316a.54.54 0 0 1-.347.113h-.181a.492.492 0 0 1-.334-.113.394.394 0 0 1-.135-.316v-1.205h2.016v-.697c0-.261-.004-.513-.013-.753a2.783 2.783 0 0 0-.062-.563.83.83 0 0 0-.312-.553 1.426 1.426 0 0 0-.607-.284 1.927 1.927 0 0 0-.711-.026c-.24.034-.447.113-.628.24-.226.152-.39.36-.493.623-.102.26-.152.624-.152 1.09v1.56c0 .657.175 1.128.521 1.406.32.261.657.393 1.012.393h.104c.398-.024.748-.194 1.053-.507.228-.228.342-.529.342-.899-.013-.12-.027-.252-.054-.394zm-.9-1.486h-1.115l.025-.619c0-.136.051-.246.152-.337a.539.539 0 0 1 .369-.134h.051c.15 0 .279.043.386.127a.423.423 0 0 1 .159.344l-.027.619z"
        }))), React.createElement("a", {
          className: "icon-link instagram-icon",
          href: "https://www.instagram.com/skavaus/",
          target: "_blank"
        }, React.createElement("svg", {
          className: "svg-icon",
          xmlns: "http://www.w3.org/2000/svg",
          viewBox: "0 0 169.063 169.063"
        }, React.createElement("g", null, React.createElement("path", {
          d: "M122.406,0H46.654C20.929,0,0,20.93,0,46.655v75.752c0,25.726,20.929,46.655,46.654,46.655h75.752 c25.727,0,46.656-20.93,46.656-46.655V46.655C169.063,20.93,148.133,0,122.406,0z M154.063,122.407 c0,17.455-14.201,31.655-31.656,31.655H46.654C29.2,154.063,15,139.862,15,122.407V46.655C15,29.201,29.2,15,46.654,15h75.752 c17.455,0,31.656,14.201,31.656,31.655V122.407z"
        }), React.createElement("path", {
          d: "M84.531,40.97c-24.021,0-43.563,19.542-43.563,43.563c0,24.02,19.542,43.561,43.563,43.561s43.563-19.541,43.563-43.561 C128.094,60.512,108.552,40.97,84.531,40.97z M84.531,113.093c-15.749,0-28.563-12.812-28.563-28.561 c0-15.75,12.813-28.563,28.563-28.563s28.563,12.813,28.563,28.563C113.094,100.281,100.28,113.093,84.531,113.093z"
        }), React.createElement("path", {
          d: "M129.921,28.251c-2.89,0-5.729,1.17-7.77,3.22c-2.051,2.04-3.23,4.88-3.23,7.78c0,2.891,1.18,5.73,3.23,7.78 c2.04,2.04,4.88,3.22,7.77,3.22c2.9,0,5.73-1.18,7.78-3.22c2.05-2.05,3.22-4.89,3.22-7.78c0-2.9-1.17-5.74-3.22-7.78 C135.661,29.421,132.821,28.251,129.921,28.251z"
        }))))));
      };
    
      return React.createElement("footer", {
        className: "footer-wrapper"
      }, React.createElement("section", {
        className: "top-footer"
      }, renderTopPanel()), React.createElement("section", {
        className: "bottom-footer"
      }, renderBottomPanel()));
    };

    ReactDOM.render(
        React.createElement(FooterComp, null),
        document.getElementById(appendFooterElemName)
      )
}

var Footer_React = StudioWidgetV2.extend(
{
    /*
     * Triggered when initializing a widget and will have the code that invokes rendering of the widget
     * setParentContainer(JQueryParentContainerDOM) - binds event to this container
     * setItemContainer(JQueryItemContainerDOM) - binds studio item events for respective item containers
     * bindEvents() - binds the studio event to this widget
     */
    init: function()
    {
        var thisObj = this;
        thisObj._super.apply(thisObj, arguments);
        thisObj.render();
        if ((typeof(Studio) != "undefined") && Studio)
        {

        }
    },

    /*
     * Triggered from init method and is used to render the widget
     */
    render: function()
    {
        var thisObj = this;
        var widgetProperties = thisObj.getProperties();
        var elem = thisObj.getContainer();
        var items = thisObj.getItems();
        var connectorProperties = thisObj.getConnectorProperties();

        /*
         * API to get base path of your uploaded widget API file
         */
        var widgetBasePath = thisObj.getWidgetBasePath();
        if (elem)
        {
            var containerDiv = $(".scfClientRenderedContainer", elem);
            if (containerDiv.length)
            {
                $(containerDiv).empty();
            }
            else
            {
                containerDiv = document.createElement('div');
                containerDiv.className = "scfClientRenderedContainer";
                $(elem).append(containerDiv);
            }

            if (
                $("#" + appendFooterElemName, elem).length > 0 &&
                typeof ReactDOM.render === "function" &&
                typeof React === "object"
              ) {
                ReactFooterCompLoad(this);
              }
        
            // var html = "";

            // $(containerDiv).append(html);

            // for (var idx = 0; idx < items.length; idx++)
            // {
            //     var itemDiv = document.createElement("div");
            //     itemDiv.innerHTML = "Facets for item " + (idx + 1);
            //     itemDiv.className = "Footer_React_ItemContainer";
            //     var facets = items[idx].facets;
            //     for (var facetName in facets)
            //     {
            //         var facetDiv = document.createElement("div");
            //         facetDiv.innerHTML = facetName + " : " + facets[facetName];
            //         $(itemDiv).append(facetDiv);
            //     }
            //     $(containerDiv).append(itemDiv);
            // }
        }

        /*
         * API to bind global events to the item DOM :
         *  thisObj.sksBindItemEvent();
         * 
         * API to bind item events to the item DOM :
         *  thisObj.sksBindItemEvent(JQueryItemContainerSelector, ItemIdx);
         * JQueryItemContainerSelector - A JQuery selector that returns an array of DOMs that represents the individual item inside the item container, to which the hotspot needs to be bound.
         * ItemIdx (Optional) - To bind the item events to a specific item.
         */
        thisObj.sksBindItemEvent();

        /*
         * API to refresh the previously bound events when a resize or orientation change occurs.
         *  thisObj.sksRefreshEvents(ItemIdx);
         * ItemIdx (Optional) - To refresh events for a specific item. Default value is 0.
         */
        $(window).resize(function()
        {
            thisObj.sksRefreshEvents();
        });
    },
});